/*****************************************************************************************
 *                                      SEU-3D
 *                     -------------------------------------------------
 * Copyright (c) 2005, Yuan XU<xychn15@yahoo.com.cn>,Chang'e SHI<evelinesce@yahoo.com.cn>
 * Copyright (c) 2006, Yuan XU<xuyuan.cn@gmail.com>,Chunlu JIANG<JamAceWatermelon@gmail.com>
 * Southeast University ,China
 * All rights reserved.
 *
 * Additionally,this program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 ****************************************************************************************/

 
#include "Player.h"

Player::Player()
{
}

Player::~Player()
{
}

void Player::playPlayOn()
{
	
	int num = WM->getMyNum();
	PlayerType myType = FM->getPlayerType(num);
	
	switch ( myType )
	{
		case PT_GOALKEEPER:
			goaliePlayOn();
			break;
		
		case PT_DEFENDER_CENTRAL:
		case PT_DEFENDER_SWEEPER:
		case PT_DEFENDER_WING:
			defenderPlayOn();
			break;
		
		case PT_MIDFIELDER_SWEEPER:
			midfielderSweeperPlayOn();
			break;
		
		case PT_MIDFIELDER_CENTER:
		case PT_MIDFIELDER_WING:
			midfielderAttackPlayOn();
			break;
		
		case PT_ATTACKER_CENTRAL:
		case PT_ATTACKER_WING:
			attackerPlayOn();
			break;
		
		default:
			defaultPlayOn();
			break;
	}

	
}

void Player::goaliePlayOn()
{
	
	if ( ( WM->getMyGlobalPos()-WM->getBallGlobalPos() ).Length() <5)  //在catch范围就抓球
	//if(WM->getBallGlobalPos().x()<-15)
	{

		putActionInQueue(SKILL->dashToBall());
		putActionInQueue(SKILL->CatchBall());
		putActionInQueue(SKILL->defendGoal());
		//putActionInQueue(SKILL->clearBall());
		
		
	}
	
	else
	{
		putActionInQueue( SKILL->runStrategicPos() );
		putActionInQueue(SKILL->defendGoal());  
	}

	
}

void Player::defenderPlayOn()
{

	if ( WM->isFastestOur() )   //如果我们是最快到球的
{
		if(WM->getMyFreedom()>=5)
		{
				putActionInQueue( SKILL->fastDribble(WM->getOppGoalCenter()) );
			if( ( WM->getBallGlobalPos()-WM->getPlayerGlobalPos(false,1) ).Length() <10 )   //在离对方一定距离内就踢底球，否则就掉门
					
						putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force,25) );
		}
		putActionInQueue( SKILL->pass(5) );
		
}	
	else
	{
		if ( (WM->getBallGlobalPos()).x() >=-16&&(WM->getBallGlobalPos()).x() <-10 ) 
		{ //如果球在后半场
			unsigned int WhichToGo;
			if ( (WM->getTeammateGlobalPos(2) - WM->getBallGlobalPos()).Length() >= 
					(WM->getTeammateGlobalPos(3) - WM->getBallGlobalPos()).Length() ) WhichToGo=3;
			else WhichToGo=2;
			if (WM->getMyNum()==WhichToGo) 
				{
					putActionInQueue( SKILL->dashToBall());
					putActionInQueue( SKILL->clearBall() );
					
				}
			else putActionInQueue( SKILL->runStrategicPos() );
		}  
		if ( (WM->getBallGlobalPos()).x() >=-10&&(WM->getBallGlobalPos()).x() <=0 ) 
		{ //如果球在后半场
			unsigned int WhichToGo;
			if ( (WM->getTeammateGlobalPos(2) - WM->getBallGlobalPos()).Length() >= 
					(WM->getTeammateGlobalPos(3) - WM->getBallGlobalPos()).Length() ) WhichToGo=3;
			else WhichToGo=2;
			if (WM->getMyNum()==WhichToGo) 
				{
					putActionInQueue( SKILL->interceptBall0() );
					putActionInQueue( SKILL->clearBall() );
					
				}
			else putActionInQueue( SKILL->runStrategicPos() );
		}  
		
		else putActionInQueue( SKILL->runStrategicPos() );
	}

}

void Player::midfielderSweeperPlayOn()
{
	defaultPlayOn();
	
}

void Player::midfielderAttackPlayOn()
{
	defaultPlayOn();
	
}

void Player::attackerPlayOn()
{
//	defaultPlayOn();
	        //xj added

	if ( WM->isFastestOur() )
	{
		
		if (WM->getMyNum() == 5)
			{
				
				if(WM->getMyFreedom()>=5)
				
					{
						putActionInQueue( SKILL->runStrategicPos() );
					if( (WM->getBallGlobalPos()-WM->getPlayerGlobalPos(false,1) ).Length() <5 )   //在离对方一定距离内就踢底球，否则就掉门
						putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force,0) );
					
					if( ( WM->getBallGlobalPos()-WM->getPlayerGlobalPos(false,1) ).Length() <10 )   //在离对方一定距离内就踢底球，否则就吊门
						putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force,10) );
					if( ( WM->getBallGlobalPos()-WM->getPlayerGlobalPos(false,1) ).Length() <15 )   //在离对方一定距离内就踢底球，否则就吊门
						putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force,25) );
						putActionInQueue( SKILL->dribble(WM->getOppGoalCenter()) );
					}
		    	else 
					{
						putActionInQueue( SKILL->pass(4));
						putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force ,25) );
					}
			}
			else if (WM->getMyNum() ==4)
			{
				
				if(WM->getMyFreedom()>=5)
				
				{
							
						putActionInQueue( SKILL->runStrategicPos() );
					if( ( WM->getBallGlobalPos()-WM->getPlayerGlobalPos(false,1) ).Length() <5)   //在离对方一定距离内就踢底球，否则就掉门
						putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force,0 ));
					if( ( WM->getBallGlobalPos()-WM->getPlayerGlobalPos(false,1)).Length() <10 )   //在离对方一定距离内就踢底球，否则就掉门
						putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force,10) );
					if( ( WM->getBallGlobalPos()-WM->getPlayerGlobalPos(false,1) ).Length() <15 )   //在离对方一定距离内就踢底球，否则就掉门
						putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force,25) );
						putActionInQueue( SKILL->dribble(WM->getOppGoalCenter()) );	
				}	
					else 
					{
							putActionInQueue( SKILL->pass(5));
							putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force,25) );
					}
						
			}
	}
	else
	{
		if ( (WM->getBallGlobalPos()).x() >= 0 ) 
			{ //如果球在前半场
		unsigned int WhichToGo;
			if ( (WM->getTeammateGlobalPos(4) - WM->getBallGlobalPos()).Length() >= 
					(WM->getTeammateGlobalPos(5) - WM->getBallGlobalPos()).Length() ) WhichToGo=5;
			else WhichToGo=4;
			if (WM->getMyNum()== WhichToGo) 
			{
				
				putActionInQueue( SKILL->interceptBall0() );
				putActionInQueue( SKILL->clearBall() );			
		    }
				
			else putActionInQueue( SKILL->runStrategicPos() );
			}
		else putActionInQueue( SKILL->runStrategicPos() );
					
	}
}

void Player::defaultPlayOn()
{
	if ( WM->isFastestOur() )
	{
		GL_PRINT("test","fastest");
		putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force,25) );
	}
	else
	{
		GL_PRINT("test","runStrategicPos");
		putActionInQueue( SKILL->runStrategicPos() );
	}
} 

//////////////////////////// TEST ////////////////////////////
void Player::testIntercept()
{
}

void Player::testTurnCycle()
{
}

void Player::testSkill()
{
}
