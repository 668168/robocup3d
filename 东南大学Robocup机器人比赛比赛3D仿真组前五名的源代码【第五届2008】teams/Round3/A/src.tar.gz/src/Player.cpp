/*****************************************************************************************
 *                                      SEU-3D
 *                     -------------------------------------------------
 * Copyright (c) 2005, Yuan XU<xychn15@yahoo.com.cn>,Chang'e SHI<evelinesce@yahoo.com.cn>
 * Copyright (c) 2006, Yuan XU<xuyuan.cn@gmail.com>,Chunlu JIANG<JamAceWatermelon@gmail.com>
 * Southeast University ,China
 * All rights reserved.
 *
 * Additionally,this program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 ****************************************************************************************/

 
#include "Player.h"

const float dist_dangerous = 11;
const float dist_faraway = 6;

Player::Player()
{
}

Player::~Player()
{
}

void Player::playPlayOn()
{
	
	int num = WM->getMyNum();
	PlayerType myType = FM->getPlayerType(num);		//确定球员类型
	
	switch ( myType )
	{
		case PT_GOALKEEPER:			//守门员(1)
			goaliePlayOn();
			break;
		
		case PT_DEFENDER_CENTRAL:	//后卫(2)
		case PT_DEFENDER_SWEEPER:	//(3)
		case PT_DEFENDER_WING:		//(4)
			defenderPlayOn();
			break;
		
		case PT_MIDFIELDER_SWEEPER: //(6)
			midfielderSweeperPlayOn();
			break;
		
		case PT_MIDFIELDER_CENTER:  //(5)
		case PT_MIDFIELDER_WING:	//(7)
			midfielderAttackPlayOn();
			break;
		
		case PT_ATTACKER_CENTRAL:	//前锋(9)
			attackerPlayOn();
			break;
		case PT_ATTACKER_WING:		//(8)
			atkwingPlayOn();
			break;
		
		default:
			defaultPlayOn();
			break;
	}	
}

void Player::goaliePlayOn()		//守门员动作
{
	Vector3f save_position, save_position_reformed;	
	Action catchAction;
	Step step_cycle = 3,Max_step_cycle = 81;
	Time savepre = 0;
	
	putActionInQueue( SKILL->defendGoal() );

	if( (WM->getMyGlobalPos()-WM->getBallGlobalPos()).Length() < 7.5f && abs(WM->getMyGlobalPos().x()) >= 15.5f )
	{
		save_position=WM->predictInterceptPos(savepre,WM->getMyGlobalPos(),WM->getMyGlobalVel());
		save_position_reformed=SKILL->setInterceptPosBeforeGoal(save_position);
		putActionInQueue( SKILL->dashTo(save_position_reformed) );
		//added start
		catchAction.setCatch();
		for(Step loop = 1; loop <= Max_step_cycle; loop *= step_cycle)
		{
			catchAction.setTime(WM->getRealTime() + loop);  //根据时间戳来排队
			putActionInQueue(catchAction);
		}
		//added end
	}
	else
	{
		putActionInQueue( SKILL->runStrategicPos() );
	}
}

void Player::defenderPlayOn()		//后卫动作
{
	Vector3f defendposition;
	float mindist;
	Num nearest, nearestOppo, closestOppo2Ball;
	
	Vector3f mykickpos = WM->getMyGlobalPos();
				
	nearest = WM->getClosestOurNum2Pos(mykickpos, mindist);		//nearest teammate
	nearestOppo = WM->getClosestOppNum2Pos( mykickpos );		//nearest opponent
	closestOppo2Ball = WM->getClosestOppNum2Ball();			    //nearest opponent to Ball
		
	Vector3f posOpp = WM->getOpponentGlobalPos( nearestOppo );
		
	float dis_me_nearestOpp = (mykickpos - posOpp).Length();
		
	PlayerType nearestPlayerType = FM->getPlayerType(nearest);
	
	
	if( WM->isFastestOur() )
	{	
		Step defendpre;
		defendposition=WM->predictInterceptPos(defendpre,WM->getMyGlobalPos());
		putActionInQueue( SKILL->dashTo(defendposition) );
	
		Vector3f nearestTeammatePos = WM->getTeammateGlobalPos( nearest );
		float dis_me_nearest = (mykickpos-nearestTeammatePos).Length();
		
		switch (nearestPlayerType)
		{
			case PT_ATTACKER_CENTRAL:
			case PT_ATTACKER_WING:
				if ( dis_me_nearest <= 3 )				
					putActionInQueue( SKILL->safePass(nearest) );
				else
					putActionInQueue( SKILL->fastDribble( WM->getOppGoalCenter() ) );
				break;
			default:
				putActionInQueue( SKILL->clearBall() );
				break;
		}
	}
	else
	{
		/*
		putActionInQueue( SKILL->runStrategicPos() );		
		if( (WM->getMyGlobalPos()-WM->getBallGlobalPos()).Length() < 1 )
		{
			if ( dis_me_nearestOpp < 1 )
				putActionInQueue( SKILL->clearBall() );
			else
				putActionInQueue( SKILL->dribble( WM->getOppGoalCenter() ) );
		}
		else if( (WM->getMyGlobalPos()-WM->getBallGlobalPos()).Length() < 6 )
			putActionInQueue( SKILL->interceptBall0() );
		else
		*/
		putActionInQueue( SKILL->runStrategicPos() );
	}
}


//前锋动作
void Player::atkwingPlayOn()
{
	attackerPlayOn();
}

void Player::attackerPlayOn()
{
	float mindist_1;
	Num nearest, nearestOppo, closestOppo2Ball;
	
	if ( WM->isFastestOur() )
	{	
		GL_PRINT("test","fastest");
		Vector3f mykickpos = WM->getMyGlobalPos();
		nearest = WM->getClosestOurNum2Pos(mykickpos, mindist_1);	//nearest teammate
		nearestOppo = WM->getClosestOppNum2Pos( mykickpos );		//nearest opponent
		closestOppo2Ball = WM->getClosestOppNum2Ball();			    //nearest opponent to Ball
		//added 5-15,5-19
		Vector3f posTeammate = WM->getTeammateGlobalPos( nearest );
		Vector3f posOpp = WM->getOpponentGlobalPos( nearestOppo );
		Vector3f posOpp2Ball = WM->getOpponentGlobalPos( closestOppo2Ball );
		
		Vector3f posBall = WM->getBallGlobalPos();
		float opp2Ball = ( posOpp2Ball - posBall ).Length();
		float dist2teammate = ( mykickpos - posTeammate ).Length();
		//end
		PlayerType nearestPlayerType = FM->getPlayerType(nearest);
		
		//Step defendpre;
		//defendposition=WM->predictInterceptPos(defendpre,WM->getMyGlobalPos());
		//putActionInQueue( SKILL->dashTo(defendposition) );

		if ( abs( WM->getMyGlobalPos().x() ) >=18.5f && abs( WM->getMyGlobalPos().y() ) >=9.5f )
			putActionInQueue( SKILL->dribble(Vector3f(0,0,0)) );
		else if ( abs( (WM->getMyGlobalPos().x()-WM->getOppGoalCenter().x() ) ) > 22.0f )
			putActionInQueue( SKILL->clearBall() );
		else if ( abs( (WM->getMyGlobalPos().x()-WM->getOppGoalCenter().x() ) ) > 12.5f )
		{
			switch(nearestPlayerType)
			{
				case PT_ATTACKER_CENTRAL:
				case PT_ATTACKER_WING:
					if ( (mykickpos - posOpp).Length() < 1.5f && dist2teammate < 2.0f)
					{
						putActionInQueue( SKILL->fastPass( nearest ) );
					}
					else if( opp2Ball < 0.5f )
					{
						putActionInQueue( SKILL->interceptBall() );
					}
					else
					{
						putActionInQueue( SKILL->dribble( WM->getOppGoalCenter() ) );
					}
					break;
				default:
					putActionInQueue( SKILL->fastPass( nearest ) );
					//putActionInQueue( SKILL->fastDribble( WM->getOppGoalCenter() ) );
					break;
			}
		}
		else if( abs( (WM->getMyGlobalPos().x()-WM->getOppBaseLine()) ) > 6 )
		{
			if ( ( WM->isSpaceAhead() ) || ( dist2teammate > 3) )
				putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force, 25) ); 
			else
				putActionInQueue( SKILL->fastPass( nearest ) );
		}
		else
		{
			putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force/2.0f, 50) );
		}
	}
	else
	{
		GL_PRINT("test","runStrategicPos");
		putActionInQueue( SKILL->runStrategicPos() );
	}
	/*
	if ( WM->isFastestOur() )
	{
		GL_PRINT("test","fastest");
		if ( abs( (WM->getMyGlobalPos().x()-WM->getOppBaseLine()) ) < 10 )
			putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force,20) ); 
		else
			putActionInQueue( SKILL->kickBetween(WM->getOppGoalLeft(),WM->getOppGoalRight(),max_kick_force,30) ); 
	}
	else
	{
		GL_PRINT("test","runStrategicPos");
		putActionInQueue( SKILL->runStrategicPos() );
	}
	*/
}

void Player::defaultPlayOn()
{
}

void Player::midfielderSweeperPlayOn()
{
}

void Player::midfielderAttackPlayOn()
{
}

//////////////////////////// TEST ////////////////////////////
void Player::testIntercept()
{
}

void Player::testTurnCycle()
{
}

void Player::testSkill()
{
}
