/*****************************************************************************************
 *                                      SEU-3D
 *                     -------------------------------------------------
 * Copyright (c) 2005, Yuan XU<xychn15@yahoo.com.cn>,Chang'e SHI<evelinesce@yahoo.com.cn>
 * Copyright (c) 2006, Yuan XU<xuyuan.cn@gmail.com>,Chunlu JIANG<JamAceWatermelon@gmail.com>
 * Southeast University ,China
 * All rights reserved.
 *
 * Additionally,this program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 ****************************************************************************************/

 
#include "Player.h"

Player::Player()
{
}

Player::~Player()
{
}

void Player::playPlayOn()
{
	
	int num = WM->getMyNum();
	PlayerType myType = FM->getPlayerType(num);
	
	switch ( myType )
	{
		case PT_GOALKEEPER:
			goaliePlayOn();
			break;
		
		case PT_DEFENDER_CENTRAL:
		case PT_DEFENDER_SWEEPER:
			defenderPlayOn();
			break;
		
		case PT_DEFENDER_WING:
			defenderWingPlayOn();
			break;
		
		case PT_MIDFIELDER_SWEEPER:
			midfielderSweeperPlayOn();
			break;
		
		case PT_MIDFIELDER_CENTER:
		case PT_MIDFIELDER_WING:
			midfielderAttackPlayOn();
			break;
		
		case PT_ATTACKER_CENTRAL:
		case PT_ATTACKER_WING:
			attackerPlayOn();
			break;
		
		default:
			defaultPlayOn();
			break;
	}

	
}

void Player::goaliePlayOn()
{
	//defaultPlayOn();
	putActionInQueue( SKILL->defendGoal());
}

//2007-5-16 CTH
void Player::defenderPlayOn()
{
//	defaultPlayOn();
	float width = WM -> getFieldWidth();
	float length = WM -> getFieldLength();
	Vector3f posBall = WM ->getBallGlobalPos();
	Rectangle defCenterBox(-0.5*length+3.5, -0.2*width, -0.16*length, 0.2*width);
	Num dangerOppNum;
	Vector3f posMe = WM -> getMyGlobalPos();
	Vector3f posGoalCenter = WM->getOppGoalCenter();
	Vector3f posGoalLeft = WM->getOppGoalLeft();
	Vector3f posGoalRight = WM->getOppGoalRight();
	Vector3f Attackdist =posGoalCenter-posBall; 
	
	if( WM->isFastestOur() )
	{
		//小角度正对门时，技能优先级依次为：射门－>带球->传球
		Num oppNum = WM -> isSpaceAhead(6, 90.0f);
		if( oppNum == 0 )//下面一大段表明，无论如何，至少45'内无人
		{
			if( ( (WM -> isSpaceAhead( 0.5, 100.0f)) == 0 ) || ( WM -> isShootAble( posMe, posBall )) )//两个条件只要有一个满足就可以射门
			{
				if( abs( (posBall - posGoalCenter).Length() )<0.6*max_kick_distance )
					putActionInQueue( SKILL -> shoot() );
				else//距离太长，无法射门的情况，讨论得较细
				{
					if( (WM -> isSpaceAhead( 0.5, 100.0f)) != 0 )//此时一定有10'三点一线
						putActionInQueue(SKILL -> dribble(posGoalCenter, 7, 9));//用较大的力气向对方球门带球一次，试图摆脱；此时方向比较正，不会有太大方向偏差
					else//一定不满足三点一线，此时一定满足小范围内无敌人，环境较安全
						putActionInQueue(SKILL -> dribble(posGoalCenter, 7, 7));//正常调整方向向对方球门带球￥2￥；
				}
			}
			else//此时两个条件都不满足
				if(posMe[0]>7)
					putActionInQueue(SKILL -> pass( SKILL -> selectPass(4) ));//选择性传球；此时无法带球也无法射门
				else
					if(posMe[0]>-5)//在对方半场
						if(posMe[1]>0)
							putActionInQueue( SKILL->dribble( Vector3f(20,5,0.22), max_kick_force, 50) );
						else
							putActionInQueue( SKILL->dribble( Vector3f(20,-5,0.22), max_kick_force, 50) );
					else//在我方半场
						if((WM -> getTeammateGlobalPos( Num(4)))[0] > 0.0f)//4号在前场
							putActionInQueue(SKILL -> kickBetween((WM -> getTeammateGlobalPos( Num(4)))+Vector3f(4.0f,3,0.22), (WM -> getTeammateGlobalPos( Num(4)))+Vector3f(4.0f,-3,0.22), max_kick_force, 30));
						else
							putActionInQueue(SKILL -> kickBetween(posGoalLeft+Vector3f(-7.7,0,0.22), posGoalRight+Vector3f(-7.7,0,0.22), max_kick_force, 30));
		}
		//小角度正对门的方向有人阻挡时，技能优先级依次为：传球－>带球－>射门（守门员阻挡除外）
		else//小角度正对门的方向有人阻挡
		{
			if( (posMe[0] < 0.0f))//在我方半场
			{
				Vector3f velMe = WM -> getMyGlobalVel();
				Vector3f velBall = WM -> getBallGlobalVel();
				posBall += velBall*0.2f;				
				Vector3f posPolar = posMe + (posBall - posMe).Normalized() * velMe.Length() * 0.2f;
				
				if( (WM -> isSpaceAhead(2, 180.0f)) != 0)//两米内有人
					putActionInQueue(SKILL -> clearBall());//开大脚
				else
					if((WM -> isSpaceAhead(4, 90.0f)) != 0 )//两到四米内有人
						putActionInQueue(SKILL -> dribble( posGoalCenter, max_kick_force, max_kick_angle));//挑球
					else//四到六米内有人
						if((WM -> isSpaceAhead(4, 60.0f)) != 0)//人在中间
							putActionInQueue( SKILL -> pass( SKILL -> selectPass(4)));//传球(4)
						else//人在偏两边就过人
							if((WM -> getOpponentGlobalPos(oppNum))[1] < posMe[1])//对方在我右边
								if(posMe[0] > ((WM -> getFieldWidth())/2.0f)-1.0f)
									putActionInQueue(SKILL -> clearBall());
								else
									putActionInQueue(SKILL -> dribble( (posMe+Vector3f(1,1,0.22)), 0.07f*max_kick_force, 0.2f*max_kick_angle));
							else
								if(posMe[0] < (-(WM -> getFieldWidth())/2.0f)+1.0f )
									putActionInQueue(SKILL -> clearBall());
								else
									putActionInQueue(SKILL -> dribble( (posMe+Vector3f(1,-1,0.22)), 0.07f*max_kick_force, 0.2f*max_kick_angle));
			}
			else//在对方半场
			{
				if((WM -> isSpaceAhead(1, 90.0f)) != 0)
					putActionInQueue(SKILL -> clearBall());
				else
					if((WM -> isSpaceAhead(2, 90.0f)) != 0)
						putActionInQueue(SKILL -> kickBetween(posGoalLeft, posGoalRight, max_kick_force, 30));
					else
						if((WM -> isSpaceAhead(3, 90.0f)) != 0)
							putActionInQueue(SKILL -> dribble( posGoalCenter, max_kick_force, max_kick_angle));
						else
							if( (posBall - posGoalCenter).Length() <0.6*max_kick_distance )
								putActionInQueue( SKILL -> shoot() );
							else
							{
								if((WM -> isSpaceAhead(3, 60.0f)) != 0)//人在中间
									putActionInQueue( SKILL -> pass( SKILL -> selectPass(4)));//传球(4)
								else//人在偏两边就过人
									if((WM -> getOpponentGlobalPos(oppNum))[1] < posMe[1])//对方在我右边
										if(posMe[0] > ((WM -> getFieldWidth())/2.0f)-1.0f)
											putActionInQueue(SKILL -> clearBall());
										else
											putActionInQueue(SKILL -> dribble( (posMe+Vector3f(1,1,0.22)), 0.07f*max_kick_force, 0.2f*max_kick_angle));
									else
										if(posMe[0] < (-(WM -> getFieldWidth())/2.0f)+1.0f )
											putActionInQueue(SKILL -> clearBall());
										else
											putActionInQueue(SKILL -> dribble( (posMe+Vector3f(1,-1,0.22)), 0.07f*max_kick_force, 0.2f*max_kick_angle));
							}
			}
		}
	}
	else
	{
		//if(WM -> isOppInBox(clearBox, dangerOppNum))
		//{
		//	putActionInQueue(SKILL -> defendCertainOpp(false, dangerOppNum));	
		//}
		//else
		if ( WM -> isOppInBox(defCenterBox, dangerOppNum))
			putActionInQueue(SKILL -> defendCertainOpp(5, dangerOppNum));	
		else
			putActionInQueue( SKILL -> runStrategicPos() );	
	}
}

void Player::defenderWingPlayOn()
{
	Vector3f posBall = WM->getBallGlobalPos();
	Vector3f posGoalCenter = WM->getOppGoalCenter();
	Vector3f posGoalLeft = WM->getOppGoalLeft();
	Vector3f posGoalRight = WM->getOppGoalRight();
	Vector3f Attackdist =posGoalCenter-posBall; 
	Vector3f posMe = WM -> getMyGlobalPos();
	Vector3f pos4 = WM -> getTeammateGlobalPos(Num(4));
	
	float width = WM -> getFieldWidth();
	float length = WM -> getFieldLength();
	float goal2Ball = (posGoalCenter - posBall).Length();
	
	if(WM -> isFastestOur())//我是最快的
	{
		if(posBall[0] > 0.5 * length - 4)//球在对方底线不同于4//角球
		{
			putActionInQueue(SKILL -> pass(Num(4)));//传球给4
		}
		else
		{
			if(abs(posBall[1]) > 0.5 * width - 1)//球在两侧边线上//边界球
			{
				if(goal2Ball < 0.7 * max_kick_distance)//距离够射门_范围放宽
					putActionInQueue(SKILL -> shoot());//射门
				else//开界外球,距离无法射门
					putActionInQueue( SKILL -> kickBetween(pos4+Vector3f(2,2,0), pos4+Vector3f(2,-2,0), SKILL -> calGroundKickForce(1.7*(pos4 - posMe + Vector3f(3,0,0)).Length()), 30));//kickBetween(4号身前的位置+2)
			}
			else//不是罚球,一般情况下的行为
			{
				if(posMe[0] > 0)//我在前场
				{
					if(goal2Ball > 0.6 * max_kick_distance)//距离可以射门
						putActionInQueue(SKILL -> shoot());//射门//不管哪里有人我都射门
					else//距离够不着射门
					{
						if(WM -> isSpaceAhead(0.6, 150) != 0)//指向球门前方0.6米150度有敌人
						{
							putActionInQueue(SKILL -> shoot());//射门//类似开大脚
						}
						else//自己前方较大范围无贴身敌人
						{
							if(WM -> isSpaceAhead(6,80) == 0)//指向球门前方6米80度没敌人
							{
								putActionInQueue(SKILL -> dribble(posGoalCenter, 6, 9));//自己朝球门带球
							}
							else
							{
								if(WM -> isSpaceAhead(4, 80) == 0)//指向球门前方4米80度内没敌人
								{
									putActionInQueue(SKILL -> pass(SKILL -> selectPass(4)));
								}
								else
								{
									if(WM -> isSpaceAhead(2,80))//前方2米80度内没敌人
										putActionInQueue(SKILL -> fastDribble(posBall, max_kick_force, max_kick_angle));//挑球试图过人//fastDriible
									else
										putActionInQueue(SKILL -> kickBetween(posGoalLeft, posGoalRight, max_kick_force, 30));//左右门柱,最大力,30度
								}
							}
						}
					}
				}
				else//我在后场
				{
					if(WM -> isSpaceAhead(3,100) == 0)//指向球门前方3米100度没敌人
						putActionInQueue(SKILL -> kickBetween(pos4+Vector3f(3,1,0), pos4+Vector3f(3,-1,0), max_kick_force, 30));//4号身前的位置+3
					else
						putActionInQueue(SKILL -> clearBall());//直接开大脚
				}
			}		
		}
	}
	else
	{
		Num myNum = WM -> getMyNum();
		switch (myNum)
		{
			case Num (2):
				defenderLeft();
				break;
			case Num (3):
				defenderRight();
				break;	
		}			
	}
}

void Player::defenderLeft()
{
	float fieldWidth = WM -> getFieldWidth();
	float ourBaseLine= WM -> getOurBaseLine();
	
	Vector3f ballPos = WM ->getBallGlobalPos();
	Vector3f goaliePos = WM -> getTeammateGlobalPos(1);

	Rectangle rectLeft( ourBaseLine, fieldWidth/2, 3, fieldWidth/8 );
	Rectangle rectCentral ( ourBaseLine+1.0f, fieldWidth/8, 0.0f, -fieldWidth/8);

	Num dangerOppNum;
	if( (((goaliePos - ballPos).Length()) < 0.7) && ((abs(goaliePos[1])) < 5.0))//球被守门员catch
		putActionInQueue(SKILL -> runTo( Vector3f(-3.3f, 5.0f, 0.22f), Vector3f(0.2,0.2,0)));
	else
	{
		if( WM -> isOppInBox(rectLeft, dangerOppNum) )//首要防区内有敌人
		//盯人。左后45度，2.8个人半径位置
			putActionInQueue(SKILL -> defendCertainOpp(2, dangerOppNum));
		else
			if( ( WM -> isOppInBox(rectCentral, dangerOppNum) ) && rectCentral[ballPos] )//中间有敌人且有球
			{
				//盯有球的人；
				putActionInQueue(SKILL -> interceptBall0());
			}
		else//中间、两边都没敌人
			putActionInQueue(SKILL -> runTo( Vector3f(0.0f, 5.0f, 0.22f), Vector3f(0.2,0.2,0)));		
	}
}

void Player::defenderRight()
{
	float fieldWidth = WM -> getFieldWidth();
	float ourBaseLine= WM -> getOurBaseLine();
	
	Vector3f ballPos = WM ->getBallGlobalPos();
	Vector3f goaliePos = WM -> getTeammateGlobalPos(1);

	Rectangle rectRight( ourBaseLine, -fieldWidth/8, 3, -fieldWidth/2 );
	Rectangle rectCentral ( ourBaseLine+1.0f, fieldWidth/8, 0.0f, -fieldWidth/8);

	Num dangerOppNum;
	if((((goaliePos - ballPos).Length()) < 0.7) && ((abs(goaliePos[1])) < 5.0))//球被守门员catch
		putActionInQueue(SKILL -> runTo( Vector3f(3.3f, -5.0f, 0.22f), Vector3f(0.2,0.2,0)));
	else
	{
		if( WM -> isOppInBox(rectRight, dangerOppNum) )//首要防区内有敌人
		//盯人。左后45度，2.8个人半径位置
			putActionInQueue(SKILL -> defendCertainOpp(3, dangerOppNum));
		else
			if( ( WM -> isOppInBox(rectCentral, dangerOppNum) ) && rectCentral[ballPos] )//中间有敌人且有求
			{
			//盯有球的人；
			putActionInQueue(SKILL -> interceptBall0());
		}
		else//中间、两边都没敌人
			putActionInQueue(SKILL -> runTo( Vector3f(0.0f, -5.0f, 0.22f), Vector3f(0.2,0.2,0)));		
	}
}

void Player::midfielderSweeperPlayOn()
{
	defaultPlayOn();
}

void Player::midfielderAttackPlayOn()
{
	defaultPlayOn();
}

void Player::attackerPlayOn()
{
	Vector3f posMe = WM -> getMyGlobalPos();
	Vector3f posBall = WM -> getBallGlobalPos();
	Vector3f posGoalCenter = WM -> getOppGoalCenter();
	Vector3f posGoalLeft = WM -> getOppGoalLeft();
	Vector3f posGoalRight = WM -> getOppGoalRight();
	
	float goal2Ball = (posGoalCenter - posBall).Length();
	float width = WM -> getFieldWidth();
	float length = WM -> getFieldLength();
	
	if(((WM -> getOpponentGlobalPos(Num(1))) - posBall).Length() > 0.7)//球不在对方守门员手里
	{
		if(WM -> isFastestOur())//我是最快的
		{
			if(posBall[0] > (0.5 * length - 0.5) )//球在对方底线,或者是角球
			{
				if(posMe[1] > 0.5)//我在左边
					putActionInQueue(SKILL -> dribble(Vector3f( 0.5 * length - 6, posGoalLeft[0]+5, 0.22), 7, 9)); //回带向左边定点(较大力);
				else
					putActionInQueue(SKILL -> dribble(Vector3f( 0.5 * length - 6, posGoalRight[0]-5, 0.22), 7, 9)); //回带向右边定点(较大力);
			}
			else
			{
				if(posBall[1] > 0.5 * width - 1)//球在左边线上//左边界球
				{
					if(goal2Ball < 0.7 * max_kick_distance)//距离够射门_范围放宽
						putActionInQueue(SKILL -> kickBetween(posGoalLeft, posGoalRight, max_kick_force, 30));//射门最大力30度;
					else//开界外球,距离无法射门		
						if((WM -> getTeammateGlobalPos(Num(2)))[0] > 3)//2号比较靠前
							putActionInQueue(SKILL -> pass(Num(2)));//传给2号
						else
							putActionInQueue(SKILL -> dribble(posGoalCenter, 7, 9));//带向定点;
				}
				else
				{
					if(posBall[1] < -0.5 * width + 1)//球在右边线上//右边界球
					{
						if(goal2Ball < 0.7 * max_kick_distance)//距离够射门_范围放宽
							putActionInQueue(SKILL -> kickBetween(posGoalLeft, posGoalRight, max_kick_force, 30));//射门最大力30度;
						else//开界外球,距离无法射门		
							if((WM -> getTeammateGlobalPos(Num(3)))[0] > 3)//3号比较靠前
								putActionInQueue(SKILL -> pass(Num(3)));//传给3号
							else
								putActionInQueue(SKILL -> dribble(posGoalCenter, 7, 9));//带向定点;
					}
					else//不是罚球,一般情况下的行为
					{
						if(goal2Ball < 0.6 * max_kick_distance)//距离可以射门
							putActionInQueue(SKILL -> shoot());//射门//不管哪里有人我都射门
						else//距离够不着射门
						{
							if(WM -> isSpaceAhead(0.6, 150) != 0)//指向球门前方0.6米150度有敌人
							{
								putActionInQueue(SKILL -> shoot());//类似开大脚
							}
							else//自己前方较大范围无贴身敌人
							{
								if(WM -> isSpaceAhead(6, 70) == 0)//指向球门前方6米70度没敌人
								{
									putActionInQueue(SKILL -> dribble(posGoalCenter, 6, 9));//自己朝球门带球;
								}
								else
								{
									if(WM -> isSpaceAhead(4, 70) == 0)//指向球门前方4米70度内没敌人
									{
										Num teammateNum = SKILL -> selectPass();
										if(teammateNum != 0)
											putActionInQueue(SKILL -> pass(teammateNum));//传球
										else//无人可传
											putActionInQueue(SKILL -> dribble(posGoalCenter, max_kick_force, max_kick_angle));//挑球过人//用dribble
									}
									else
									{
										if(WM -> isSpaceAhead(2,70) == 0)//前方2米70度内没敌人
											putActionInQueue(SKILL -> fastDribble(posBall, max_kick_force, max_kick_angle));//挑球试图过人//用fastdribble
										else
											putActionInQueue(SKILL -> kickBetween(posGoalLeft, posGoalRight, max_kick_force, 30));//左右门柱,最大力,30度;
									}
								}
							}
						}
					}
				}
			}
		}
		else
		{
			putActionInQueue(SKILL -> runStrategicPos());//战略跑动
		}
	}
	else//球被对方守门员catch住了
	{
		putActionInQueue(SKILL -> runTo(Vector3f(0,0,0.22)));//跑到定点
	}
}

void Player::defaultPlayOn()
{

}

//////////////////////////// TEST ////////////////////////////
void Player::testIntercept()
{
}

void Player::testTurnCycle()
{
}

void Player::testSkill()
{
}
